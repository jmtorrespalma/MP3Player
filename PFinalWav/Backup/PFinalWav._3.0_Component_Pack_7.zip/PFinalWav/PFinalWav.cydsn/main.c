/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>
#include <string.h>

char wave[25000];
uint8 intep;

uint32 setInteger(char* p){ // Get an integer from binary file
	uint32 *ptr = (uint32*) p;
	return *ptr;
}

void readRiffChunk(char* wave, uint32* chunk_size){
	if (strncmp (wave,"RIFF",4) != 0){ //Check if has the correct header
        LCD_Char_ClearDisplay();
        LCD_Char_PrintString("No RIFF");
        while(1);
    }
	
	*chunk_size = setInteger(&wave[4]); //Get size of file.
	
	if (strncmp (&wave[8],"WAVE",4) != 0){ //Check if has the correct header
        LCD_Char_ClearDisplay();
        LCD_Char_PrintString("No WAVE");
		while(1);
	}
		
}

void readFmtSubChunk(char* wave, uint32* subchunk_size, uint16* audio_format, uint16* num_channels, uint32* sample_rate, uint32* byte_rate, uint16* block_align, uint16* bits_per_sample){
	

	if (strncmp (wave,"fmt ",4) != 0){ //Check if has the correct header
        LCD_Char_ClearDisplay();
        LCD_Char_PrintString("No fmt");
		while(1);
	}

	*subchunk_size = setInteger(&wave[4]); //Needed to know where the data subchunk starts
	*audio_format = (uint16) setInteger(&wave[8]); //Audio format
	*num_channels = (uint16) setInteger(&wave[10]); //Number of channels
	*sample_rate = setInteger(&wave[12]); //Sample rate
	*byte_rate = setInteger(&wave[16]);
	*block_align = (uint16) setInteger(&wave[20]);
	*bits_per_sample = (uint16) setInteger(&wave[22]);
	
}

void readDataSubChunk(char* wave, uint32* chunk_size){
	if (strncmp (wave,"data",4) != 0){ //Check if has the correct header
        LCD_Char_ClearDisplay();
        LCD_Char_PrintString("No data");
		while(1);
	}
	
	*chunk_size = setInteger(&wave[4]); //Get size of file.
			
}

static CY_ISR( isrWAV_Interrupts ){
    intep = 1 ;
}

int main()
{
    char *riff, *fmt, *my_data, *audio_data;
	uint32 chunk_size, sample_rate, subchunk_size, byte_rate, data_size;
	uint16 audio_format, num_channels, bits_per_sample, block_align;
    
    uint32 i = 0; //Indice del siguiente dato a enviar
    uint8 play = 0;
    
    LCD_Char_Start();
    LCD_Char_ClearDisplay();
        
    //Start reading RIFF Chunk
	
	riff = wave;
	readRiffChunk(riff, &chunk_size);
    
    //Read fmt subchunk

	fmt = &wave[12];
	readFmtSubChunk(fmt, &subchunk_size, &audio_format, &num_channels, &sample_rate, &byte_rate, &block_align, &bits_per_sample);

    //Read data subchunk
    
	my_data = fmt + 8 + subchunk_size;
	readDataSubChunk(my_data, &data_size);

	audio_data = my_data + 8; // Keep only the sound data.
    
    VDAC8_Start(); // Se inicializa el DAC
    CyGlobalIntEnable; /* Uncomment this line to enable global interrupts. */
    
    isrWAV_Start(); //Activamos el ISR
    isrWAV_SetVector (&isrWAV_Interrupts);
    
    while(i < data_size)
    {
        if(!Pin_Play_Pause_Read()){ //Si pulsamos play, hacemos que suene
            play ^= 1;
            while(!Pin_Play_Pause_Read()); //Mientras pulsado
        }
        if(intep && play){
            intep = 0;
            VDAC8_SetValue(audio_data[i]);
            ++i;
        }       
    }
    LCD_Char_ClearDisplay();
    LCD_Char_PrintString("Terminado");
    while(1);
}

/* [] END OF FILE */
